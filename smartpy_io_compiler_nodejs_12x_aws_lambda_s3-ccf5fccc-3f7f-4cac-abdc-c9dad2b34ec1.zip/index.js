/* Copyright 2019 Smart Chain Arena LLC. */

exports.handler = async(event, context, callback) => {
    // console.log("Incoming Event: ", event);

    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };


    /////////////////////UTILITIES////////////////////////////////
    const library = {
        bs58check: require('bs58check'),
        sodium: require('libsodium-wrappers-sumo'),
    };

    const prefix = {
        tz1: new Uint8Array([6, 161, 159]),
        tz2: new Uint8Array([6, 161, 161]),
        tz2: new Uint8Array([6, 161, 164]),
        KT: new Uint8Array([2, 90, 121]),

        edpk: new Uint8Array([13, 15, 37, 217]),
        edsk2: new Uint8Array([13, 15, 58, 7]),
        spsk: new Uint8Array([17, 162, 224, 201]),
        p2sk: new Uint8Array([16, 81, 238, 189]),

        sppk: new Uint8Array([3, 254, 226, 86]),
        p2pk: new Uint8Array([3, 178, 139, 127]),

        edsk: new Uint8Array([43, 246, 78, 7]),
        edsig: new Uint8Array([9, 245, 205, 134, 18]),
        spsig1: new Uint8Array([13, 115, 101, 19, 63]),
        p2sig: new Uint8Array([54, 240, 44, 52]),
        sig: new Uint8Array([4, 130, 43]),

        Net: new Uint8Array([87, 82, 0]),
        nce: new Uint8Array([69, 220, 169]),
        b: new Uint8Array([1, 52]),
        o: new Uint8Array([5, 116]),
        Lo: new Uint8Array([133, 233]),
        LLo: new Uint8Array([29, 159, 109]),
        P: new Uint8Array([2, 170]),
        Co: new Uint8Array([79, 179]),
        id: new Uint8Array([153, 103]),
    };

    const utility = {
        b58cencode: function(payload, prefix) {
            const n = new Uint8Array(prefix.length + payload.length);
            n.set(prefix);
            n.set(payload, prefix.length);
            return library.bs58check.encode(new Buffer(n, 'hex'));
        },
        b58cdecode: (enc, prefix) => library.bs58check.decode(enc).slice(prefix.length),
        buf2hex: function(buffer) {
            const byteArray = new Uint8Array(buffer),
                hexParts = [];
            for (let i = 0; i < byteArray.length; i++) {
                let hex = byteArray[i].toString(16);
                let paddedHex = ('00' + hex).slice(-2);
                hexParts.push(paddedHex);
            }
            return hexParts.join('');
        },
        hex2buf: function(hex) {
            return new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function(h) {
                return parseInt(h, 16)
            }));
        },
        mergebuf: function(b1, b2) {
            var r = new Uint8Array(b1.length + b2.length);
            r.set(b1);
            r.set(b2, b1.length);
            return r;
        },
    };
    /////////////////////////////////////////////////////////////

    const fs = require('fs');
    const path = require("path");


    var mode = "";
    var compile = undefined;
    var outputDir = "";
    var targetStorage = "";
    var targetCode = "";
    var targetTypes = "";
    var scenario = undefined; //html rendering not necessary for nodejs

    await library.sodium.ready;
    await library.bs58check.ready;

    global.eztz = {
        prefix: prefix,
        utility: utility,
        library: library
    };
    global.sodium = library.sodium;

    var smartml = require(__dirname + '/smartmljs.bc.js');

    function ppToFile(filename, target, value) {
        if (target) {
            fs.writeFileSync(target, value);
        }
        else if (outputDir) {
            fs.writeFileSync(outputDir + "/" + filename, value);
        }
        else {
            console.log("==== " + filename + " ====");
            console.log(value);
        }
    }


    // const args = process.argv.slice(2);
    let args = -1;
    let bucket = "io.blockget.tezos";
    let filename = "theContractDemoExpression.smlse";

    if (event.Records) {
        let testEvent = {
            "args": [
                "--compile",
                "theContractDemoExpression.smlse",
                "--targetCode",
                "theContractDemoCode.tz",
                "--targetStorage",
                "theContractDemoStorage.tz",
                "--targetTypes",
                "theContractDemoTypes.tz"
            ]
        }
        args = testEvent.args;
        bucket = event.Records[0].s3.bucket.name;
        filename = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
        const message = `File is uploaded in - ${bucket} -> ${filename}`; //// File is uploaded in - io.blockget.tezos.in -> test1.smlse
        console.log(message);
        if (filename.search(".smlse") !== -1) {
            args[1] = filename;
            args[3] = filename + "Code.tz";
            args[5] = filename + "Storage.tz";
            args[7] = filename + "Types.tz";
        }
        else {
            return; //bad filename
        }
        // callback(null, message);
        // return;

    }
    else if (event.args && event.args.length !== -1) {
        args = event.args;
    }
    else {
        return; // none of the above
    }
    // console.log(typeof args, args);
    // node smartmlbasic.js --compile "Expression.smlse" --targetCode "Code.tz" --targetStorage "Storage.tz" --targetTypes "Types.tz"

    for (var i = 0; i < args.length; i++) {
        switch (args[i]) {
            case "--compile":
                mode = "compile";
                break;
            case "--outputDir":
                mode = "outputDir";
                break;
            case "--targetCode":
                mode = "targetCode";
                break;
            case "--targetStorage":
                mode = "targetStorage";
                break;
            case "--targetTypes":
                mode = "targetTypes";
                break;
            case "--scenario":
                mode = "scenario";
                break;
            default:
                if (mode == "compile") {
                    compile = args[i];
                }
                else if (mode == "outputDir") {
                    outputDir = args[i];
                }
                else if (mode == "targetCode") {
                    targetCode = args[i];
                }
                else if (mode == "targetStorage") {
                    targetStorage = args[i];
                }
                else if (mode == "targetTypes") {
                    targetTypes = args[i];
                }
                else if (mode == "scenario") {
                    scenario = args[i];
                }
                else {
                    throw "Bad command line. " + args[i];
                }
        }
    }

    outputDir = '/tmp';

    // console.log("mode", mode);
    // console.log("compile", compile);
    // console.log("outputDir", outputDir);
    // console.log("targetCode", targetCode);
    // console.log("targetStorage", targetStorage);
    // console.log("targetTypes", targetTypes);
    // console.log("scenario", scenario);

    // https://s3.amazonaws.com/io.blockget.tezos/theContractDemoExpression.smlse
    const AWS = require("aws-sdk");
    let s3GET = new AWS.S3();

    const params = {
        Bucket: bucket, //io.blockget.tezos blockget.io
        Key: filename //"theContractDemoExpression.smlse" index.html
    };

    // console.log("get from s3");
    await s3GET.getObject(params, function(err, data) {
        if (err) {
            console.log(err); // an error occurred
            // console.log(err, err.stack); // an error occurred
            response.body = "error";
        }
        else {
            // console.log(typeof data);
            let bufferSMLSE = data.Body;
            // console.log(smlse.toString());
            response.body = "s3 success";
            console.log(compile);
            //        return response;

            if (compile != undefined) {
                // const s_expr = fs.readFileSync(args[1], 'utf8');
                try {
                    const contract = smartml.importContract(bufferSMLSE.toString());
                    const ccs = smartml.compileContractStorage(contract);
                    const pct = smartml.ppContractTypes(contract);

                    const compiledContract = smartml.compileContract(contract);
                    const ccm = smartml.compiledContract_to_michelson(compiledContract);

                    const paramsSMLSE = {
                        Bucket: "io.blockget.tezos.out",
                        Key: args[1],
                        Body: bufferSMLSE
                    };
                    const paramsCCS = {
                        Bucket: "io.blockget.tezos.out",
                        Key: args[5],
                        Body: Buffer.from(ccs, 'utf8')
                    };
                    const paramsPCT = {
                        Bucket: "io.blockget.tezos.out",
                        Key: args[7],
                        Body: Buffer.from(pct, 'utf8')
                    };
                    const paramsCCM = {
                        Bucket: "io.blockget.tezos.out",
                        Key: args[3],
                        Body: Buffer.from(ccm, 'utf8')
                    };
                    const paramsCCMJSON = {
                        Bucket: "io.blockget.tezos.out",
                        Key: args[3] + ".json",
                        Body: Buffer.from(JSON.stringify(ccm), 'utf8')
                    };

                    const loop = [
                        paramsSMLSE, paramsCCS, paramsPCT, paramsCCM, paramsCCMJSON
                    ]

                    const s3PUT = new AWS.S3();

                    for (var i = 0; i < loop.length; i++) {
                        let etag = s3PUT.putObject(loop[i]).promise();
                        console.log(loop[i].Key, etag);
                    }

                    return;

                    //save the files into the file system - from the creators
                    ppToFile("contractStorage.tz", targetStorage, smartml.compileContractStorage(contract));
                    ppToFile("contractTypes.tz", targetTypes, smartml.ppContractTypes(contract));
                    ppToFile("contractCode.tz", targetCode, smartml.compiledContract_to_michelson(compiledContract));
                    ppToFile("contractCode.tz.json", targetCode ? (targetCode + ".json") : targetCode, smartml.compiledContract_to_micheline(compiledContract));
                }
                catch (exn) {
                    console.error("Exception while handling " + args[1])
                    console.error(smartml.stringOfException(false, exn));
                    process.exit(1)
                }
            } else {
                
            }


        }
    });


    const bucketz = await s3GET.listBuckets().promise();

    response.body = JSON.stringify(bucketz.toString());
    return response;

};


/*

README:

This is a port of the SmartPy.io compiler. The original file takes command line arguments to run. This program is triggered by an event request.

The event request occurs when a file is added the S3 bucket ("in"), this action automatically triggers the Lambda to run, the Lambda gets the SMLSE file from S3 and compiles it into 4 Tezos files (Storage, Type, Code, Code.json). All files are then put in another S3 bucket ("out").

Additional information is contained in the notes.txt file included next to this file.

Log after storing the files in S3 "out" bucket
2020-06-22T10:46:17.727Z	1645aaba-b718-428f-a2ce-8675d9d0ba9e	INFO	theContractDemoExpression.smlse
2020-06-22T10:46:18.467Z	1645aaba-b718-428f-a2ce-8675d9d0ba9e	INFO	theContractDemoExpression.smlse Promise { <pending> }
2020-06-22T10:46:18.470Z	1645aaba-b718-428f-a2ce-8675d9d0ba9e	INFO	theContractDemoStorage.tz Promise { <pending> }
2020-06-22T10:46:18.529Z	1645aaba-b718-428f-a2ce-8675d9d0ba9e	INFO	theContractDemoTypes.tz Promise { <pending> }
2020-06-22T10:46:18.587Z	1645aaba-b718-428f-a2ce-8675d9d0ba9e	INFO	theContractDemoCode.tz Promise { <pending> }

*/