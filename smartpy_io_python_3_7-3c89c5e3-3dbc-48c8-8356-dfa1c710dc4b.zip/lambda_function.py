import json
import boto3
import os
import platform
print (platform.python_version())

def lambda_handler(event, context):
    

    ## Copyright 2019 Smart Chain Arena LLC. ##
    
    # To run this script, we need to setup a PYTHONPATH to the
    # SmartPyBasic directory.
    
    # If the SmartPyBasic directory is ~/SmartPyBasic, then
    #   PYTHONPATH=~/SmartPyBasic python3 demo.py
    # or
    #   ~/SmartPyBasic/SmartPy.sh run demo.py
    # should work.
    import platform
    # print (platform.python_version())
    import site
    # site.getsitepackages() # list of global package locations
    # print (site.getsitepackages())
    import sys
    import pathlib
    # print (pathlib.Path(__file__).parent.absolute())
    # from os.path import dirname, abspath
    # d = dirname(dirname(abspath(__file__)))
    # sys.path[3] = d 
    # print (sys.path)
    
    import smartpy as sp
    
    
    class MyContract(sp.Contract):
        def __init__(self, myParameter1, myParameter2):
            self.init(myParameter1 = myParameter1,
                      myParameter2 = myParameter2)
        @sp.entry_point
        def myEntryPoint(self, params):
            sp.verify(self.data.myParameter1 <= 123)
            self.data.myParameter1 += params
        def toJSON(self):
            return json.dumps(self, default=lambda o: o.__dict__, 
                sort_keys=True, indent=4)
    
    # We evaluate a contract with parameters.
    contract = MyContract("12", [13])    
    # print(type(contract))
    # print(contract.export())
    
    
    # We can save the contract.
    open('/tmp/targetSmlse', 'w').write(contract.export())
    print('smlse saved at /tmp/targetSmlse')
    
    # We can read the contract.
    target = open('/tmp/targetSmlse', 'r')
    print('target read from /tmp/targetSmlse')
    print(target.read())
    
    
    # to do: SAVE THE TARGET TO S3
    
    # client = boto3.client('s3')
    # BUCKET = 'io.blockget.smartpy.io'
    # KEY = os.urandom(32)
    # s3 = boto3.client('s3')
    
    # print("Uploading S3 object with SSE-C")
    # s3.put_object(Bucket=BUCKET,
    #               Key='encrypt-key',
    #               Body=b'foobar',
    #               SSECustomerKey=KEY,
    #               SSECustomerAlgorithm='AES256')
    # print("Done")
    
    # # Getting the object:
    # print("Getting S3 object...")
    # # Note how we're using the same ``KEY`` we
    # # created earlier.
    # response = s3.get_object(Bucket=BUCKET,
    #                          Key='encrypt-key',
    #                          SSECustomerKey=KEY,
    #                          SSECustomerAlgorithm='AES256')
    # print("Done, response body:")
    # print(response['Body'].read())

    
    
    
    #We can compile the contract.
    # It can be done with the following command.
    # import smartpybasic as spb
    # spb.compileContract(contract, targetBaseFilename = "/home/georgemck/htdocs/workspaces-vaccinex/smartpy-dev/SmartPyBasic/myContractDemo")
    # spb.compileContract(contract, targetBaseFilename = "/tmp/myContractDemo")
    # print("Contract compiled in /tmp/myContractDemoCode.tz")
    
    
    
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('to do: SAVE THE TARGET TO S3! Running Python version: ' + platform.python_version())
    }
