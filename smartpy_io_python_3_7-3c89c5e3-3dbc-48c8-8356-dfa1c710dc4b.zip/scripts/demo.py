## Copyright 2019 Smart Chain Arena LLC. ##

# To run this script, we need to setup a PYTHONPATH to the
# SmartPyBasic directory.

# If the SmartPyBasic directory is ~/SmartPyBasic, then
#   PYTHONPATH=~/SmartPyBasic python3 demo.py
# or
#   ~/SmartPyBasic/SmartPy.sh run demo.py
# should work.
import platform
# print (platform.python_version())
import site
# site.getsitepackages() # list of global package locations
# print (site.getsitepackages())
import sys
import pathlib
# print (pathlib.Path(__file__).parent.absolute())
from os.path import dirname, abspath
sys.path[3] = dirname(dirname(abspath(__file__))) 
# print (sys.path)


import smartpy as sp

class MyContract(sp.Contract):
    def __init__(self, myParameter1, myParameter2):
        self.init(myParameter1 = myParameter1,
                  myParameter2 = myParameter2)
    @sp.entry_point
    def myEntryPoint(self, params):
        sp.verify(self.data.myParameter1 <= 123)
        self.data.myParameter1 += params

# We evaluate a contract with parameters.
contract = MyContract(12, 13)

# We need to compile the contract.
# It can be done with the following command.
import smartpybasic as spb
# spb.compileContract(contract, targetBaseFilename = "/home/georgemck/htdocs/workspaces-vaccinex/smartpy-dev/SmartPyBasic/myContractDemo")
spb.compileContract(contract, targetBaseFilename = "/tmp/myContractDemo")

print("Contract compiled in /tmp/myContractDemoCode.tz")
